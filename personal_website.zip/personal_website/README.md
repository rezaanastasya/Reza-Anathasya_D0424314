# Sasha Anathasya Personal Website

A personal portfolio website for Sasha Anathasya, featuring an elegant and aesthetic design with a soft pink, dark, and purple color scheme.

## Features

- Responsive design for all devices
- Custom cursor effects
- Smooth scrolling and animations
- Interactive navigation
- Skills visualization
- Timeline journey section
- Contact form (demo)

## Technologies Used

- HTML5
- CSS3
- JavaScript (Vanilla)
- Font Awesome Icons
- Google Fonts

## How to Use

1. Clone this repository to your local machine
2. Open index.html in your browser to view the website
3. Customize the content as needed

## Deployment

This website can be easily deployed on GitHub Pages or any static web hosting service.

## Credits

Created with ❤️ for Sasha Anathasya
